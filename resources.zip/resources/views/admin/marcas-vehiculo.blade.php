@extends('layouts.portalapp')

@section('content')

    <div class="row">
        <div id="app" class="col-lg-12 pl-5 pr-5">
            <vehicle-brand-component></vehicle-brand-component>
        </div>
    </div>

@endsection

