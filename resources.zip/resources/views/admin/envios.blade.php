@extends('layouts.portalapp')

@section('content')

    <div class="row">
        <div id="app" class="col-lg-12 pl-5 pr-5">
            <envios-component></envios-component>
        </div>
    </div>

@endsection