@extends('layouts.portalapp')

@section('content')

    <div class="row">
        <div id="app" class="col-lg-12 pl-5 pr-5">
            <detalle-usuario-component></detalle-usuario-component>
        </div>
    </div>

@endsection
