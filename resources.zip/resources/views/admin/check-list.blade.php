@extends('layouts.portalapp')

@section('content')

    <div class="row">
        <div id="app" class="col-lg-12 pl-5 pr-5">
            <checklist-component></checklist-component>
        </div>
    </div>

@endsection