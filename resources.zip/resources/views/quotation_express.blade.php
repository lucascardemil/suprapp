@extends('layouts.quotation')

@section('content')


<div id="app" class="col-lg-12 pl-5 pr-5">
    <quotationexpress-component></quotationexpress-component>
</div>


@endsection