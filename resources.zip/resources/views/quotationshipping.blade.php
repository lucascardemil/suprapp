@extends('layouts.app')

@section('content')


<div id="app" class="col-lg-12 pl-5 pr-5">
    <quotationshipping-component></quotationshipping-component>
</div>


@endsection

<style>
    body{
        background-color: #e3e3e3 !important;
    }
    .card{
        box-shadow: 0px 3px 10px -2px rgb(0 0 0 / 20%);
    }
</style>