<template>
    <form action="POST" v-on:submit.prevent="">
        <div id="modalQuotationclient" class="modal fade modal-fullscreen">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header  bg-dark text-white">
                        <h4>Administrar Cotización Formal</h4>
                        <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                            <span>&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <!--<div id="accordion">-->
                                <div class="card">



                                    <div class="card-header">
                                        <h5 class="mb-0">Nuevo Producto</h5>
                                    </div>


                                    <div class="card-body">
                                        <form action="POST" v-on:submit.prevent="createDetailclient">

                                            <div class="row mb-3">

                                                <div class="col-lg-4">
                                                    <label for="cliente">Producto</label>
                                                    <SelectProduct></SelectProduct>
                                                </div>

                                                <div class="col-lg-4">
                                                    <label for="product">Nombre Producto</label>
                                                    <input required type="text" name="product" class="form-control"
                                                        v-model="newDetailclient.product">
                                                </div>

                                                <div class="col-lg-4">
                                                    <label for="product">Código</label>
                                                    <input type="text" name="product" class="form-control"
                                                        v-model="newDetailclient.detail">
                                                </div>
                                            </div>
                                            <div class="row">

                                                <div class="col-lg-2">
                                                    <label for="precio">Precio</label>
                                                    <input type="number" name="precio" class="form-control"
                                                        v-model="newDetailclient.price" @keyup="sumTotalProduct" required>

                                                </div>

                                                <div class="col-lg-1">
                                                    <label for="cantidad">Cantidad</label>
                                                    <input type="number" name="quantity" class="form-control" required
                                                        v-model="newDetailclient.quantity" @keyup="sumTotalProduct" min="0">
                                                </div>

                                                <div class="col-lg-1">
                                                    <label for="percentage">%</label>
                                                    <input type="number" name="percentage" class="form-control"
                                                        v-model="newDetailclient.percentage" @keyup="sumTotalProduct"
                                                        min="0">
                                                </div>

                                                <div class="col-lg-1">
                                                    <label for="aditional">Adicional</label>
                                                    <input type="number" name="aditional" class="form-control"
                                                        v-model="newDetailclient.aditional" @keyup="sumTotalProduct"
                                                        min="0">
                                                </div>

                                                <div class="col-lg-1">
                                                    <label for="transport">Flete</label>
                                                    <input type="number" name="transport" class="form-control"
                                                        v-model="newDetailclient.transport" @keyup="sumTotalProduct"
                                                        min="0">
                                                </div>

                                                <div class="col-lg-1">
                                                    <label for="utilidad">Utilidad</label>
                                                    <input type="number" name="utilidad" class="form-control"
                                                        v-model="newDetailclient.utility" min="0" disabled>
                                                </div>

                                                <div class="col-lg-2">
                                                    <label for="plazo">Días de Plazo</label>
                                                    <input type="text" name="plazo" class="form-control"
                                                        v-model="newDetailclient.days">
                                                </div>

                                                <div class="col-lg-2">
                                                    <label for="total">Total</label>
                                                    <input type="number" name="total" class="form-control"
                                                        v-model="newDetailclient.total" min="0" disabled>
                                                </div>

                                                <div class="col-lg-1 mt-2">
                                                    <label></label>
                                                    <button type="submit" class="btn btn-success form-control">
                                                        <i class="fas fa-plus-square"></i> Guardar
                                                    </button>
                                                </div>

                                            </div>

                                        </form>
                                    </div>
                                    <!--</div>-->
                                </div>
                                <!--</div>-->
                            </div>

                            <div class="col-lg-12 table-responsive">

                                <table class="table table-bordered table-striped mt-3 table-sm">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Producto</th>
                                            <th>Código</th>
                                            <th>Plazo</th>
                                            <th>Valor Neto ($)</th>
                                            <th>Cantidad</th>
                                            <th>Porcentaje</th>
                                            <th>Adicional ($)</th>
                                            <th>Transporte ($)</th>
                                            <th>Utilidad ($)</th>
                                            <th>Total Neto ($)</th>
                                            <th>Total + IVA ($)</th>
                                            <th>Acción</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <tr v-for="(detailLocal, index) in detailclients" :key="detailLocal.id">
                                            <td width="10px">{{ index + 1 }}</td>
                                            <td>{{ detailLocal.product }}</td>
                                            <td>{{ detailLocal.detail }}</td>
                                            <td>{{ detailLocal.days }}</td>
                                            <td>{{ detailLocal.price | currency('', 0, { thousandsSeparator: '.' }) }}</td>
                                            <td>{{ detailLocal.quantity }}</td>
                                            <td>{{ detailLocal.percentage + '%' }}</td>
                                            <td>{{ detailLocal.aditional | currency('', 0, { thousandsSeparator: '.' }) }}
                                            </td>
                                            <td>{{ detailLocal.transport | currency('', 0, { thousandsSeparator: '.' }) }}
                                            </td>
                                            <td>{{ detailLocal.utility | currency('', 0, { thousandsSeparator: '.' }) }}
                                            </td>


                                            <td>{{ detailLocal.price_neto | currency('', 0, { thousandsSeparator: '.' }) }}</td>
                                            <th>{{ detailLocal.total | currency('', 0, { thousandsSeparator: '.' }) }}</th>
                                            <td>
                                                <a href="#" class="btn btn-warning btn-sm"
                                                    @click.prevent="editDetailclient({ detailLocal })" data-toggle="tooltip"
                                                    data-placement="top" title="Editar">
                                                    <i class="fas fa-edit"></i>
                                                </a>

                                                <a href="#" class="btn btn-danger btn-sm"
                                                    @click.prevent="deleteDetailclient({ id: detailLocal.id })"
                                                    data-toggle="tooltip" data-placement="top" title="Eliminar">
                                                    <i class="fas fa-ban"></i>
                                                </a>
                                            </td>
                                        </tr>

                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <th>Total: {{ totalAdicional | currency('', 0, { thousandsSeparator: '.' }) }}
                                            </th>
                                            <th>Total: {{ totalTransporte | currency('', 0, { thousandsSeparator: '.' }) }}
                                            </th>
                                            <th>Total: {{ totalUtilidad | currency('', 0, { thousandsSeparator: '.' }) }}
                                            </th>
                                            <th>Total: {{ totalQuotationclient | currency('', 0, {
                                                thousandsSeparator: '.'
                                            }) }}</th>
                                            <th>Total + IVA: {{ totalQuotationclientIVA | currency('', 0, {
                                                thousandsSeparator: '.'
                                            }) }}</th>
                                        </tr>
                                    </tbody>
                                </table>

                            </div>

                        </div>

                    </div>
                    <div class="modal-footer">
                        <a class="btn btn-danger" href="#" role="button" @click.prevent="pdfQuotationclient">
                            <i class="far fa-file-pdf"></i> PDF
                        </a>

                        <a class="btn btn-danger" href="#" role="button" @click.prevent="pdfIvaQuotationclient">
                            <i class="far fa-file-pdf"></i> PDF IVA Incluido
                        </a>

                    </div>
                </div>
            </div>
        </div>
    </form>
</template>

<script>

import { loadProgressBar } from 'axios-progress-bar'
import { mapState, mapGetters, mapActions } from 'vuex'
import SelectProduct from '../Product/Select'

export default {
    components: { SelectProduct },
    computed: {
        ...mapState(['detailclients', 'totalQuotationclient', 'totalUtilidad', 'totalTransporte', 'totalAdicional',
            'totalQuotationclientIVA', 'newDetailclient', 'totalDetailclient', 'totalProductIvaFlete','errorsLaravel']),
        ...mapGetters([])
    },
    methods: {
        ...mapActions(['createDetailclient', 'editDetailclient', 'deleteDetailclient',
            'pdfQuotationclient', 'pdfIvaQuotationclient', 'sumTotalProduct'])
    },
    created() {
        this.$store.dispatch('fleteDefect')
        this.$store.dispatch('utilidadDefect')
    }
}
</script>

